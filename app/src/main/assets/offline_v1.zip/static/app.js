document.getElementById('mode').textContent = '✅ 离线包（本地文件）';
document.getElementById('dynamic').innerHTML =
  '✅ JS 也从本地加载成功<br>' +
  '加载时间：' + new Date().toLocaleTimeString();
